from flask import Blueprint, request, jsonify
from flask_cors import cross_origin

cart_bp = Blueprint('cart', __name__)

@cart_bp.route('/calculate-total', methods=['POST'])
@cross_origin()
def calculate_total():
    try:
        data = request.get_json()
        items = data.get('items', [])
        
        total = 0
        for item in items:
            price = float(item.get('price', 0))
            quantity = int(item.get('quantity', 0))
            total += price * quantity
        
        return jsonify({
            'success': True,
            'total': total,
            'item_count': len(items),
            'total_quantity': sum(int(item.get('quantity', 0)) for item in items)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

